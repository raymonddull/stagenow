Thank you for your interest in NoviiRemote Deluxe for Pocket PC!

This is a complete full-functioned version of the NoviiRemote Deluxe software for
Pocket PC handhelds, ver 3.1 (build 05.08.30a, released in August 2005).

1. Installation
===============

I M P O R T A N T. Do not remove the previous version of NoviiRemote 2.x from your
handheld. You may lose your customized codebase. Some time NoviiRemote 2.x and
NoviiRemote Deluxe will live together on your handheld. When you'll import
your customized codebases from NoviiRemote 2.x to NoviiRemote Deluxe, you may
remove NoviiRemote 2.x.

If you already have the prvious version of NoviiRemote Deluxe installed on your
handheld, do not remote it. Just install the new version above the previous one.

The contents are as follows:

 * !readme.txt
   This is read-me instruction file.

 * Setup_NRD_PPC_3_1_050830a.exe
   This is a Windows installation wizard, which guides you through several steps of
   installation procedure.

Extract the contents of the zip file to the temporary folder, run the installation program,
and follow instructions.

Please let us know if you need assistance with this installation. If you have any trouble
whatsoever, we'll be glad to help.

Any comments and suggestions are welcome.

We hope you enjoy our software, and are pleased to have you as our customer.

2. Registration
===============

This is a complete full-functioned version. However without a registration pdb file, the 
application will stop its work in ten days after the very first launch on your handheld.

To resume work of NoviiRemote Deluxe you need a registration pdb file. If you've already
ordered the application, you have got the registration file too. You must install the
file to the My Documents folder on your Pocket PC.


If for some reason you have not got the registration pdb file, you should register
NoviiRemote Deluxe by sending the proof of purchase to  nrdppc@novii.com. In response
you'll receive the registration file.

3. Technical support
====================

Please visit our web site at http://www.novii.tv for information about our products,
User Guides, tutorials and other useful information.  If you cannot find answers to your
questions on our web site, please write to us at nrdppc@novii.com.

4. Contacts
===========

E-mail: nrdppc@novii.com 

Web: www.novii.tv


5. To purchase please refer to www.novii.tv/buy

August 2005

The Novii Team
